--
-- PostgreSQL database dump
--

\restrict VHFhRYcXZmUKIBQzIsbrx8eFzjE0ru5yjGvDtCjo9pME5OrBKgqu9QZUYCo5RiQ

-- Dumped from database version 15.17
-- Dumped by pg_dump version 15.17

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: alertas; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.alertas (
    id integer NOT NULL,
    event_id uuid,
    ip text,
    status text,
    risco integer,
    score_final integer,
    source_ip text,
    threat_score integer DEFAULT 0,
    severity text DEFAULT 'LOW'::text,
    mitre_id text,
    mitre_name text,
    mitre_tactic text,
    human_summary text,
    explanation text,
    reasons jsonb,
    correlation_reasons jsonb,
    event_count integer DEFAULT 0,
    replay_id text,
    is_replay_event boolean DEFAULT false,
    ts timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    "timestamp" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    service text,
    port integer,
    event_type text,
    ip_event_count integer DEFAULT 0,
    risk_reasons jsonb,
    threat_intel_match boolean DEFAULT false,
    threat_category text,
    threat_description text,
    threat_reputation_score integer,
    threat_source text,
    correlation_window_seconds integer,
    correlation_key text,
    correlation_reason text,
    auto_response text DEFAULT 'none'::text,
    action_soc text,
    simulated_block boolean DEFAULT false,
    is_demo boolean DEFAULT false,
    occurrence_count integer DEFAULT 1,
    first_seen timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    last_seen timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    aggregated boolean DEFAULT false,
    ports jsonb,
    services jsonb,
    event_types jsonb,
    raw_event jsonb,
    mitre_techniques jsonb DEFAULT '[]'::jsonb,
    internal_rule_id text,
    internal_rule_name text,
    correlation_rule text,
    response_playbook text,
    detection_source text,
    alert_type text DEFAULT 'alert'::text,
    score_breakdown jsonb,
    score_explanation text,
    target_host text,
    target_ip text,
    target_user text,
    target_service text,
    target_port integer,
    target_container text,
    target_application text,
    environment text,
    asset_owner text,
    asset_criticality text,
    business_impact text,
    recommended_action text,
    action_reason text,
    execution_mode text DEFAULT 'simulation'::text,
    execution_status text DEFAULT 'not_executed'::text,
    execution_notes text,
    tenant_id text DEFAULT 'default'::text,
    correlation_id text,
    idempotency_key text,
    campaign_id text
);


ALTER TABLE public.alertas OWNER TO postgres;

--
-- Name: alertas_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.alertas_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.alertas_id_seq OWNER TO postgres;

--
-- Name: alertas_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.alertas_id_seq OWNED BY public.alertas.id;


--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.audit_logs (
    id integer NOT NULL,
    "timestamp" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    tenant_id text DEFAULT 'default'::text,
    actor_user text,
    actor_role text,
    action text NOT NULL,
    resource_type text,
    resource_id text,
    correlation_id text,
    source_ip text,
    success boolean DEFAULT true,
    metadata_json jsonb DEFAULT '{}'::jsonb
);


ALTER TABLE public.audit_logs OWNER TO postgres;

--
-- Name: audit_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.audit_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.audit_logs_id_seq OWNER TO postgres;

--
-- Name: audit_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.audit_logs_id_seq OWNED BY public.audit_logs.id;


--
-- Name: billing_records; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.billing_records (
    id integer NOT NULL,
    tenant_id text NOT NULL,
    billing_period text NOT NULL,
    event_count bigint DEFAULT 0,
    amount numeric(10,2) DEFAULT 0.00,
    status text DEFAULT 'pending'::text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.billing_records OWNER TO postgres;

--
-- Name: billing_records_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.billing_records_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.billing_records_id_seq OWNER TO postgres;

--
-- Name: billing_records_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.billing_records_id_seq OWNED BY public.billing_records.id;


--
-- Name: blacklist; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.blacklist (
    ip text NOT NULL,
    reason text NOT NULL,
    first_seen timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    last_seen timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    offense_count integer DEFAULT 1,
    active boolean DEFAULT true,
    response_mode text DEFAULT 'simulated_block'::text
);


ALTER TABLE public.blacklist OWNER TO postgres;

--
-- Name: incident_alerts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.incident_alerts (
    id integer NOT NULL,
    incident_id text NOT NULL,
    alert_id text NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.incident_alerts OWNER TO postgres;

--
-- Name: incident_alerts_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.incident_alerts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.incident_alerts_id_seq OWNER TO postgres;

--
-- Name: incident_alerts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.incident_alerts_id_seq OWNED BY public.incident_alerts.id;


--
-- Name: incident_audit_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.incident_audit_log (
    id integer NOT NULL,
    incident_id text NOT NULL,
    field_changed text NOT NULL,
    old_value text,
    new_value text,
    changed_by text DEFAULT 'system'::text,
    changed_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.incident_audit_log OWNER TO postgres;

--
-- Name: incident_audit_log_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.incident_audit_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.incident_audit_log_id_seq OWNER TO postgres;

--
-- Name: incident_audit_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.incident_audit_log_id_seq OWNED BY public.incident_audit_log.id;


--
-- Name: incident_overrides; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.incident_overrides (
    incident_id text NOT NULL,
    status text DEFAULT 'NEW'::text,
    analyst_notes text DEFAULT ''::text,
    assigned_to text DEFAULT ''::text,
    soc_action text DEFAULT 'investigação simulada'::text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.incident_overrides OWNER TO postgres;

--
-- Name: incidents; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.incidents (
    id integer NOT NULL,
    incident_id text NOT NULL,
    title text,
    description text,
    status text DEFAULT 'NEW'::text,
    severity text DEFAULT 'LOW'::text,
    max_score integer DEFAULT 0,
    primary_source_ip text,
    source_ips jsonb DEFAULT '[]'::jsonb,
    destination_ip text,
    usernames jsonb DEFAULT '[]'::jsonb,
    services jsonb DEFAULT '[]'::jsonb,
    event_types jsonb DEFAULT '[]'::jsonb,
    mitre_techniques jsonb DEFAULT '[]'::jsonb,
    correlation_reasons jsonb DEFAULT '[]'::jsonb,
    replay_ids jsonb DEFAULT '[]'::jsonb,
    first_seen timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    last_seen timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    event_count integer DEFAULT 0,
    human_summary text,
    analyst_notes text DEFAULT ''::text,
    assigned_to text DEFAULT ''::text,
    soc_action text DEFAULT 'investigação simulada'::text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    lifecycle_stage text DEFAULT 'Detected'::text,
    affected_assets jsonb DEFAULT '[]'::jsonb,
    evidence jsonb DEFAULT '[]'::jsonb,
    score_explanation text,
    response_playbook text,
    recommended_action text,
    execution_mode text DEFAULT 'simulation'::text,
    execution_status text DEFAULT 'not_executed'::text,
    tenant_id text DEFAULT 'default'::text,
    idempotency_key text,
    campaign_id text
);


ALTER TABLE public.incidents OWNER TO postgres;

--
-- Name: incidents_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.incidents_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.incidents_id_seq OWNER TO postgres;

--
-- Name: incidents_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.incidents_id_seq OWNED BY public.incidents.id;


--
-- Name: plans; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.plans (
    plan_id text NOT NULL,
    name text NOT NULL,
    max_eps integer DEFAULT 10,
    max_alerts_per_day integer DEFAULT 100,
    storage_retention_days integer DEFAULT 7,
    price_monthly numeric(10,2) DEFAULT 0.00
);


ALTER TABLE public.plans OWNER TO postgres;

--
-- Name: response_actions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.response_actions (
    id integer NOT NULL,
    action_id uuid NOT NULL,
    alert_id uuid NOT NULL,
    tenant_id text DEFAULT 'default'::text,
    action_type text NOT NULL,
    mode text NOT NULL,
    target_entity text,
    reason text,
    status text DEFAULT 'simulated'::text,
    metadata_json jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.response_actions OWNER TO postgres;

--
-- Name: response_actions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.response_actions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.response_actions_id_seq OWNER TO postgres;

--
-- Name: response_actions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.response_actions_id_seq OWNED BY public.response_actions.id;


--
-- Name: tenants; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tenants (
    tenant_id text NOT NULL,
    name text NOT NULL,
    plan_id text DEFAULT 'free'::text,
    api_key text NOT NULL,
    status text DEFAULT 'active'::text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.tenants OWNER TO postgres;

--
-- Name: alertas id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alertas ALTER COLUMN id SET DEFAULT nextval('public.alertas_id_seq'::regclass);


--
-- Name: audit_logs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_logs ALTER COLUMN id SET DEFAULT nextval('public.audit_logs_id_seq'::regclass);


--
-- Name: billing_records id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.billing_records ALTER COLUMN id SET DEFAULT nextval('public.billing_records_id_seq'::regclass);


--
-- Name: incident_alerts id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.incident_alerts ALTER COLUMN id SET DEFAULT nextval('public.incident_alerts_id_seq'::regclass);


--
-- Name: incident_audit_log id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.incident_audit_log ALTER COLUMN id SET DEFAULT nextval('public.incident_audit_log_id_seq'::regclass);


--
-- Name: incidents id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.incidents ALTER COLUMN id SET DEFAULT nextval('public.incidents_id_seq'::regclass);


--
-- Name: response_actions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.response_actions ALTER COLUMN id SET DEFAULT nextval('public.response_actions_id_seq'::regclass);


--
-- Data for Name: alertas; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.alertas (id, event_id, ip, status, risco, score_final, source_ip, threat_score, severity, mitre_id, mitre_name, mitre_tactic, human_summary, explanation, reasons, correlation_reasons, event_count, replay_id, is_replay_event, ts, "timestamp", service, port, event_type, ip_event_count, risk_reasons, threat_intel_match, threat_category, threat_description, threat_reputation_score, threat_source, correlation_window_seconds, correlation_key, correlation_reason, auto_response, action_soc, simulated_block, is_demo, occurrence_count, first_seen, last_seen, aggregated, ports, services, event_types, raw_event, mitre_techniques, internal_rule_id, internal_rule_name, correlation_rule, response_playbook, detection_source, alert_type, score_breakdown, score_explanation, target_host, target_ip, target_user, target_service, target_port, target_container, target_application, environment, asset_owner, asset_criticality, business_impact, recommended_action, action_reason, execution_mode, execution_status, execution_notes, tenant_id, correlation_id, idempotency_key, campaign_id) FROM stdin;
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.audit_logs (id, "timestamp", tenant_id, actor_user, actor_role, action, resource_type, resource_id, correlation_id, source_ip, success, metadata_json) FROM stdin;
\.


--
-- Data for Name: billing_records; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.billing_records (id, tenant_id, billing_period, event_count, amount, status, created_at) FROM stdin;
\.


--
-- Data for Name: blacklist; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.blacklist (ip, reason, first_seen, last_seen, offense_count, active, response_mode) FROM stdin;
\.


--
-- Data for Name: incident_alerts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.incident_alerts (id, incident_id, alert_id, created_at) FROM stdin;
\.


--
-- Data for Name: incident_audit_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.incident_audit_log (id, incident_id, field_changed, old_value, new_value, changed_by, changed_at) FROM stdin;
\.


--
-- Data for Name: incident_overrides; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.incident_overrides (incident_id, status, analyst_notes, assigned_to, soc_action, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: incidents; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.incidents (id, incident_id, title, description, status, severity, max_score, primary_source_ip, source_ips, destination_ip, usernames, services, event_types, mitre_techniques, correlation_reasons, replay_ids, first_seen, last_seen, event_count, human_summary, analyst_notes, assigned_to, soc_action, created_at, updated_at, lifecycle_stage, affected_assets, evidence, score_explanation, response_playbook, recommended_action, execution_mode, execution_status, tenant_id, idempotency_key, campaign_id) FROM stdin;
\.


--
-- Data for Name: plans; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.plans (plan_id, name, max_eps, max_alerts_per_day, storage_retention_days, price_monthly) FROM stdin;
free	Plano Gratuito	5	50	7	0.00
pro	Plano Profissional	100	5000	30	499.00
enterprise	Plano Enterprise	5000	1000000	365	4999.00
\.


--
-- Data for Name: response_actions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.response_actions (id, action_id, alert_id, tenant_id, action_type, mode, target_entity, reason, status, metadata_json, created_at) FROM stdin;
\.


--
-- Data for Name: tenants; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tenants (tenant_id, name, plan_id, api_key, status, created_at, updated_at) FROM stdin;
default	Sentinela Demo Client	enterprise	sentinela-demo-api-key	active	2026-05-13 00:12:36.252894+00	2026-05-13 00:12:36.252894+00
\.


--
-- Name: alertas_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.alertas_id_seq', 1, false);


--
-- Name: audit_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.audit_logs_id_seq', 1, false);


--
-- Name: billing_records_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.billing_records_id_seq', 1, false);


--
-- Name: incident_alerts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.incident_alerts_id_seq', 1, false);


--
-- Name: incident_audit_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.incident_audit_log_id_seq', 1, false);


--
-- Name: incidents_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.incidents_id_seq', 1, false);


--
-- Name: response_actions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.response_actions_id_seq', 1, false);


--
-- Name: alertas alertas_event_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alertas
    ADD CONSTRAINT alertas_event_id_key UNIQUE (event_id);


--
-- Name: alertas alertas_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alertas
    ADD CONSTRAINT alertas_pkey PRIMARY KEY (id);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: billing_records billing_records_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.billing_records
    ADD CONSTRAINT billing_records_pkey PRIMARY KEY (id);


--
-- Name: blacklist blacklist_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blacklist
    ADD CONSTRAINT blacklist_pkey PRIMARY KEY (ip);


--
-- Name: incident_alerts incident_alerts_incident_id_alert_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.incident_alerts
    ADD CONSTRAINT incident_alerts_incident_id_alert_id_key UNIQUE (incident_id, alert_id);


--
-- Name: incident_alerts incident_alerts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.incident_alerts
    ADD CONSTRAINT incident_alerts_pkey PRIMARY KEY (id);


--
-- Name: incident_audit_log incident_audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.incident_audit_log
    ADD CONSTRAINT incident_audit_log_pkey PRIMARY KEY (id);


--
-- Name: incident_overrides incident_overrides_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.incident_overrides
    ADD CONSTRAINT incident_overrides_pkey PRIMARY KEY (incident_id);


--
-- Name: incidents incidents_incident_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.incidents
    ADD CONSTRAINT incidents_incident_id_key UNIQUE (incident_id);


--
-- Name: incidents incidents_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.incidents
    ADD CONSTRAINT incidents_pkey PRIMARY KEY (id);


--
-- Name: plans plans_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plans
    ADD CONSTRAINT plans_pkey PRIMARY KEY (plan_id);


--
-- Name: response_actions response_actions_action_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.response_actions
    ADD CONSTRAINT response_actions_action_id_key UNIQUE (action_id);


--
-- Name: response_actions response_actions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.response_actions
    ADD CONSTRAINT response_actions_pkey PRIMARY KEY (id);


--
-- Name: tenants tenants_api_key_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT tenants_api_key_key UNIQUE (api_key);


--
-- Name: tenants tenants_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT tenants_pkey PRIMARY KEY (tenant_id);


--
-- Name: idx_alertas_campaign_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_alertas_campaign_id ON public.alertas USING btree (campaign_id);


--
-- Name: idx_alertas_idempotency_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX idx_alertas_idempotency_key ON public.alertas USING btree (idempotency_key) WHERE (idempotency_key IS NOT NULL);


--
-- Name: idx_alertas_tenant_ts; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_alertas_tenant_ts ON public.alertas USING btree (tenant_id, ts DESC);


--
-- Name: idx_audit_logs_action; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_audit_logs_action ON public.audit_logs USING btree (action);


--
-- Name: idx_audit_logs_resource_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_audit_logs_resource_type ON public.audit_logs USING btree (resource_type);


--
-- Name: idx_audit_logs_tenant_ts; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_audit_logs_tenant_ts ON public.audit_logs USING btree (tenant_id, "timestamp" DESC);


--
-- Name: idx_incident_alerts_alert_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_incident_alerts_alert_id ON public.incident_alerts USING btree (alert_id);


--
-- Name: idx_incident_alerts_incident_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_incident_alerts_incident_id ON public.incident_alerts USING btree (incident_id);


--
-- Name: idx_incident_audit_incident_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_incident_audit_incident_id ON public.incident_audit_log USING btree (incident_id);


--
-- Name: idx_incidents_campaign_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_incidents_campaign_id ON public.incidents USING btree (campaign_id);


--
-- Name: idx_incidents_idempotency_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX idx_incidents_idempotency_key ON public.incidents USING btree (idempotency_key) WHERE (idempotency_key IS NOT NULL);


--
-- Name: idx_incidents_incident_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_incidents_incident_id ON public.incidents USING btree (incident_id);


--
-- Name: idx_incidents_last_seen; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_incidents_last_seen ON public.incidents USING btree (last_seen DESC);


--
-- Name: idx_incidents_primary_source_ip; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_incidents_primary_source_ip ON public.incidents USING btree (primary_source_ip);


--
-- Name: idx_incidents_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_incidents_status ON public.incidents USING btree (status);


--
-- Name: idx_incidents_tenant_last_seen; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_incidents_tenant_last_seen ON public.incidents USING btree (tenant_id, last_seen DESC);


--
-- Name: idx_response_actions_alert_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_response_actions_alert_id ON public.response_actions USING btree (alert_id);


--
-- Name: idx_response_actions_tenant_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_response_actions_tenant_id ON public.response_actions USING btree (tenant_id);


--
-- Name: billing_records billing_records_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.billing_records
    ADD CONSTRAINT billing_records_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(tenant_id);


--
-- Name: tenants tenants_plan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT tenants_plan_id_fkey FOREIGN KEY (plan_id) REFERENCES public.plans(plan_id);


--
-- PostgreSQL database dump complete
--

\unrestrict VHFhRYcXZmUKIBQzIsbrx8eFzjE0ru5yjGvDtCjo9pME5OrBKgqu9QZUYCo5RiQ

